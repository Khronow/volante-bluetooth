VOLANTE BLUETOOTH - PROYECTO ANDROID

Incluye:
- main.py: aplicación Kivy con controles de volante, acelerador, freno,
  embrague, marchas, sensor y transmisión Bluetooth SPP mediante JSON por línea.
- buildozer.spec: configuración para generar APK Android.

COMPILAR APK (requiere Linux, conexión a Internet y espacio para Android SDK/NDK):
1. Instalar Python 3, pip, git, Java JDK 17, build-essential, zip/unzip y
   dependencias de Buildozer según su documentación oficial.
2. En esta carpeta ejecutar:
     pip install --user buildozer
     buildozer android debug
3. El APK de depuración se genera en bin/.

IMPORTANTE:
- Este entorno de trabajo no tiene Buildozer ni Android SDK/NDK instalados,
  por lo que no fue posible producir ni probar un APK aquí.
- El PC debe tener emparejado el teléfono por Bluetooth y ejecutar un receptor
  compatible con Bluetooth clásico SPP que lea líneas JSON terminadas en '\n'.
- Los nombres de permisos disponibles dependen de la versión de Android.
- Probar en el teléfono real: Bluetooth clásico SPP no funciona con dispositivos
  que solo admiten BLE.
